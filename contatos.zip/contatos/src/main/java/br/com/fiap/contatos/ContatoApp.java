package br.com.fiap.contatos;

import br.com.fiap.contatos.model.Contato;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.time.LocalDate;

public class ContatoApp {
    public static void main(String[] args) {
        Contato contato = new Contato();
        contato.setNome("Natalia Scigliano");
        contato.setEmail("nsqcar@gmail.com");
        contato.setDataNascimento(LocalDate.of(1993, 6, 21));

        //Criação EntityManager
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("contatos"); //esse nome precisa ser exatamente o nome dentro da parte de 'persistence-unit' na classe persistence.xml
        EntityManager em = emf.createEntityManager();

        //agora mandar o contato criado para o banco de dados
        em.getTransaction().begin();
        em.persist(contato);
        em.getTransaction().commit();

    }
}
